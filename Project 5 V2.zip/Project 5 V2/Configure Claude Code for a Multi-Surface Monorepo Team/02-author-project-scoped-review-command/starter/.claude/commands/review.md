---
description: Review a PR or diff against this repo's conventions and report findings by severity.
argument-hint: a PR reference (e.g. #142), a diff range (e.g. main..feature-x), or a file path
allowed-tools:
  - Read
  - Grep
  - Glob
  - Bash(git diff:*)
  - Bash(git log:*)
  - Bash(git show:*)
  - Bash(gh pr view:*)
  - Bash(gh pr diff:*)
  - Bash(gh pr checks:*)
---

# /review — team PR review

You are reviewing the diff identified by `$ARGUMENTS` against this repository's conventions. Apply the path-scoped rules in `.claude/rules/` (they auto-load based on the files touched) and the shared standards in `.claude/standards/`.

## Phase 1 — Interview pattern

Before you report anything, check whether the author's intent is actually clear from the diff alone. If it isn't, ask — a confident wrong verdict costs more trust than a clarifying question. Interview the author first, rather than reporting a finding, when you hit any of these:

- The diff touches `package.json` or `pyproject.toml` — a dependency bump might be intentional and already vetted, or might be accidental. Ask before flagging it as unreviewed.
- A public API response shape changes, or a DB column is added/removed/renamed. Ask whether downstream consumers were already accounted for before treating this as a breaking change.
- A refactor has no corresponding test changes. This could mean the behavior was already covered upstream, or it could mean coverage genuinely regressed — ask which, rather than assuming the worse case.
- The diff touches multiple surfaces at once (API + components + DB in the same PR). Ask whether this was intentionally one PR or should have been split, before reviewing each surface as if it were isolated.

## Phase 2 — Review criteria

**Must report** — always flag these, regardless of PR size or author seniority:
- Bugs: logic errors, a missing `await`, race conditions, off-by-one errors.
- Security: raw SQL built from user input, missing auth checks, secrets committed in code, `dangerouslySetInnerHTML`.
- Convention violations that the path-scoped rules in `.claude/rules/` already define.
- Breaking changes to a public API or shared schema.
- Migration safety: a migration that can't run cleanly against production data, or that isn't reversible.

**Skip** — do not report or block on these:
- Minor formatting Prettier would already catch.
- Naming bikeshedding when the existing name isn't actually wrong.
- Personal stylistic preferences that aren't written into `.claude/rules/` or `.claude/standards/`.
- TODOs that already reference a tracked ticket.

The skip list matters as much as the must-report list — flagging things nobody agreed to enforce is what erodes trust in this command over time.

## Phase 3 — Bundling: interacting vs. independent findings

Two findings are **interacting** when fixing one changes the same lines or logic the other depends on — for example, a missing `await` and a missing transaction wrapper on the same function share a fix, so bundle them into one detailed message with all the context together. The author needs to see both at once because touching one line touches the other.

Two findings are **independent** when they sit in separate functions or files with no shared fix — report these sequentially, as discrete items, so each is independently actionable and the author can address them in any order.

Heuristic: if fixing finding A would change code that finding B's fix also touches, they're interacting — bundle them. If fixing A leaves B's code completely untouched, they're independent — report them separately.

## Phase 4 — Output format

For each finding, produce:

```
[severity] path/to/file.ts:line
finding: <one-sentence description>
fix: <one-sentence recommendation>
```

Severity is `bug` | `security` | `convention` | `breaking`. End with a one-line verdict: `approve`, `comment`, or `request-changes`.

## Examples

**Example 1 — Independent findings.**

Input: a diff to `src/api/orders/handler.ts` where the handler returns `{ status: 404, body: ... }` directly instead of throwing `ApiError`, and separately calls the database with a raw interpolated SQL string instead of going through the repository layer in `src/db/`.

Output:
```
[convention] src/api/orders/handler.ts:22
finding: Handler returns a raw { status, body } object for the not-found case instead of throwing ApiError(404, ...).
fix: Throw ApiError(404, "ORDER_NOT_FOUND", ...) and let the middleware format the response.

[security] src/api/orders/handler.ts:41
finding: Order lookup builds a SQL string by interpolating the request's order ID directly.
fix: Use the parameterized query helper in src/db/orders.ts instead of string interpolation.
```
Verdict: `request-changes`

These are independent — the ApiError fix touches only the not-found branch, and the SQL fix touches only the lookup query. Neither change affects the other's lines, so they're reported as two separate items.

**Example 2 — Interacting findings.**

Input: a diff to a `refundOrder` handler that (a) is missing an `await` on the call to `paymentService.refund(...)`, (b) never wraps the refund and the DB write in `src/db/tx.ts`'s transaction helper, and (c) calls the DB write before confirming the payment service's refund actually succeeded.

Output:
```
[bug] src/api/orders/refund.ts:58
finding: refundOrder is missing await on paymentService.refund(...), doesn't wrap the refund and DB update in tx.ts's transaction helper, and writes the DB update before confirming the refund succeeded — all three affect the same three lines.
fix: Await the refund call, check its result before writing, and wrap both the refund and the DB update in a single tx.ts transaction so a failure on either side rolls back cleanly.
```
Verdict: `request-changes`

These three issues are interacting — fixing the ordering also changes where the `await` needs to sit and what falls inside the transaction boundary, so bundling them into one finding gives the author the full picture instead of three separate patches that might conflict with each other.

## Notes

- This command is project-scoped (`.claude/commands/review.md`) so everyone on the team gets the same review. If you want to layer personal preferences (e.g. a stricter accessibility check on your own PRs), put a `~/.claude/commands/review-strict.md` in your home directory — it will not affect teammates.
- If a finding requires running code or modifying files to verify, ask the author to run a specific check rather than attempting it from the review session. This command's `allowed-tools` are read-only by design.