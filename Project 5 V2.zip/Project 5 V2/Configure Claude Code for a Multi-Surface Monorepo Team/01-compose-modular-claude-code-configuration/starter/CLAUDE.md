# E-Commerce Platform — Shared Claude Code Conventions

This file is the **project-level** entry point for the e-commerce monorepo. Every teammate's Claude session loads it automatically.

## Scope: what belongs here vs. elsewhere

| Scope | Location | Shared with teammates? | Example |
|---|---|---|---|
| Project-level | `./CLAUDE.md`, `./.claude/` (this repo) | Yes — committed to version control | The API error-handling convention below |
| User-level | `~/.claude/` (your home directory) | No — lives only on your machine, never committed | Your preferred commit message style, or a personal alias for a long shell command |
| Directory-level | a `CLAUDE.md` inside a specific subdirectory | Yes, but only for teammates working in that subtree | A convention specific to one legacy module that doesn't apply repo-wide |

Project-level and directory-level files are checked into the repo, so every teammate who clones it gets the same conventions automatically. User-level settings under `~/.claude/` are personal to your machine and are never shared via version control — that's the right place for preferences that would just be noise for everyone else, not for anything a teammate needs to know to work on this codebase correctly.

## Shared standards (modular via @-imports)

The actual conventions live in focused files so this entry point stays scannable:

@.claude/standards/frontend.md
@.claude/standards/api.md
@.claude/standards/database.md
@.claude/standards/testing.md

Path-scoped rules in [.claude/rules/](.claude/rules/) layer on top of these standards and activate only when Claude is editing matching files (React components, API handlers, test files).

## Repository layout

```
src/components/   React components (functional + hooks)
src/pages/        Top-level routes
src/api/          Node.js API handlers
src/db/           PostgreSQL repository-pattern modules
```

Tests are co-located: `Foo.tsx` lives next to `Foo.test.tsx`.

## Troubleshooting

If Claude doesn't seem to be following something in this file or the imported standards, run `/memory` to see exactly which configuration files loaded for the current session — that's the fastest way to tell a missing import from a rule that simply didn't fire for the file you're editing.

## Team workflows

- `/review <pr-ref>` — codified PR review checklist. (You will author this in Exercise 2.)
- `/deploy-check` — read-only pre-deployment validation. (You will author this in Exercise 3.)

For decisions about when to use plan mode vs. direct execution on this codebase, you will produce a team decision doc in Exercise 4.