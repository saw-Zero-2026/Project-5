---
description: Enforcement rules for co-located test files — conventions that apply on top of whichever component or API rule governs the file under test.
paths:
  - "**/*.test.tsx"
  - "**/*.test.ts"
---

# Test file rules

- No snapshot assertions (`toMatchSnapshot`).
  - A snapshot passes when the output changes just as easily as when it stays correct.
  - Assert on the specific fields or behavior you actually care about instead.
- Build test fixtures with a builder function (e.g. `buildOrder({ ...overrides })`), never a hand-written literal object repeated across multiple test files.
  - If a test needs an order with one field different from the default, override that one field.
  - Don't copy the whole shape just to change one value.
- Never mock at the database layer for a handler test (no stubbing `src/db/pool.ts` or `src/db/tx.ts` directly).
  - Mock at the boundary one level up — the repository function the handler calls.
  - This keeps the test exercising the real transaction wrapper's error-handling path.
- No `setTimeout` or arbitrary sleeps to wait for async work.
  - Await the promise, or use the test runner's built-in async utilities.
  - A sleep-based wait is either too short (flaky) or too long (slow) and never actually verifies the thing it's waiting for.
- Each test covers exactly one behavior.
  - If a test's name needs "and" to describe what it checks, split it into two tests.
  - A failure should point at one broken behavior, not require reading the whole test body to figure out which assertion actually failed.