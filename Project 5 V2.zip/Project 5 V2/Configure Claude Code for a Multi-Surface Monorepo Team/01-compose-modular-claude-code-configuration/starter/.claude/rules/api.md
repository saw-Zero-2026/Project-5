---
description: Enforcement rules for API handler files — repository import boundaries and response typing beyond what the general API standard covers.
paths:
  - "src/api/**/*"
---

# API handler rules

- A handler file may only import from `src/db/` through the transaction wrapper in `src/db/tx.ts`.
  - Never import `src/db/pool.ts` directly inside a handler.
  - The pool is an implementation detail of the transaction layer, and a handler that reaches around it loses the automatic rollback-on-error behavior `tx.ts` provides.
- Handlers under `src/api/_lib/` and `src/api/_schemas/` are shared infrastructure, not endpoints.
  - Do not add route-specific logic to `_lib/` files.
  - If a helper starts needing request/response shaping specific to one route, move it into that route's own handler file instead of generalizing `_lib`.
- When a handler's response includes a field derived from a joined table, name that field explicitly in the response schema rather than spreading the raw row.
  - Example: an order's customer name pulled in alongside the order row must be named in `src/api/_schemas/responses/`, not returned as part of an unstructured join result.
  - An unnamed joined field is the most common way a schema silently drifts from what the handler actually returns.
- If you're touching a handler that calls into `src/services/payment.ts`, re-read that file's own comments before changing call order.
  - Payment operations in this codebase (charges, refunds) are sequenced deliberately.
  - Reordering two calls that look independent can double-charge or leave a refund half-applied.
