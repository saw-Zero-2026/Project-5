---
name: deploy-check
description: Read-only pre-deployment validation that checks the working tree and open PR before you ship.
context: fork
argument-hint: "no arguments needed — run this before opening or merging a deploy PR"
allowed-tools:
  - Read
  - Grep
  - Glob
  - Bash(git status:*)
  - Bash(git diff:*)
  - Bash(git log:*)
  - Bash(gh pr view:*)
  - Bash(gh pr checks:*)
---

# /deploy-check

Runs the team's pre-deployment validation checklist against the current working tree and the branch you're about to ship. Read-only by design — this skill never modifies files, never pushes, never deploys. It returns a single structured summary so the calling session can decide whether to proceed.

## Why this is a skill (not a CLAUDE.md addition)

This check is on-demand, forked, and task-specific — you only need it in the narrow window right before shipping, and running it produces a lot of verbose intermediate output (file enumeration, diff parsing, check-execution traces) that has zero value once you already have the pass/fail summary. CLAUDE.md is the opposite: always-loaded, universal guidance that every session needs regardless of what task is underway, like "tests are co-located" or "throw ApiError for validation failures." Rule of thumb: on-demand / forked / task-specific → skill; always-loaded / universal → CLAUDE.md.

## Why `context: fork`

The point of forking is to keep everything this skill has to *do* out of the main session — walking the working tree, parsing diffs, and running several enumeration passes are all necessary to reach a verdict, but none of that intermediate noise belongs in the calling conversation once the verdict is known. Only the structured pass/fail summary should ever return to the main session; the rest stays isolated in the fork and is discarded. `context: fork` is a Claude Code product feature that operates at the skill-invocation layer — conceptually, it's the same idea as the Architect's Playbook's *Branching Reality* pattern, which describes the same isolation at the session level via `fork_session`. Same principle, different layer: keep exploratory or high-volume work out of the thread that has to stay readable.

## Checks

Run all three. Each check produces a pass-or-fail verdict; if any fails, the overall summary is **fail**.

### Uncommitted changes

- Detect: run `git status --porcelain`.
- Pass: the command returns empty output — nothing staged, modified, or untracked.
- Fail: any output at all. Surface the exact file list in the verdict-summary's `detail` field so the author knows what to commit or discard before shipping.

### Migrations match repository changes

- Detect: diff the target branch against the current branch and look for any new import from `src/db/` repository modules; cross-check that a corresponding migration file was added in the same branch.
- Pass: every new repository import has a matching migration file in the diff.
- Fail: a repository import exists with no matching migration. Surface the specific import path and file in the verdict-summary's `detail` field so the author can add the missing migration before shipping.

### CI checks green on the open PR

- Detect: run `gh pr view --json statusCheckRollup` against the current branch's PR.
- Pass: every entry in `statusCheckRollup` reports `SUCCESS`.
- Fail: any entry reports a status other than `SUCCESS` (pending, failure, or error). Surface which check name failed or is still pending in the verdict-summary's `detail` field.

## Output format

Return exactly this shape to the main session:

```
verdict: pass | fail
checks:
  - name: <check-name>
    status: pass | fail
    detail: <one line or empty>
```

Do not include the raw `git status`, raw diff hunks, or full check logs in the returned summary — those stay in the fork. If the author wants to investigate a failed check, they can re-invoke the skill targeting that single check or run the underlying command themselves.

## Personalization

This skill is project-scoped (`.claude/skills/deploy-check/`) so every teammate runs the exact same three checks before shipping. If you want a stricter personal variant — say, one that additionally fails when the diff exceeds 500 lines without a long enough PR description — create a parallel skill under a different name at `~/.claude/skills/deploy-check-strict/`. Your personal variant lives only on your machine, won't be committed to the repo, and won't affect anyone else on the team.

## What this skill deliberately does not do

- It never pushes, deploys, or runs migrations. The `allowed-tools` allowlist is read-only by construction; even if a future maintainer adds `Write` here, the team's `/review` command should catch the change.
- It does not run the test suite. Tests have their own pre-merge gate in CI; duplicating that here would slow every deploy check without adding signal.
- It does not check for secrets in code. That's the job of the `gitleaks` pre-commit hook, which fails the commit, not the deploy.