"""Resume-vs-fresh decision logic for crash recovery.

The 30-minute threshold is ~1/16 of an 8-hour shift cycle: a resume inside this
window is still operating on the same shift's working set; anything older is
treated as a stale partial that should be re-started from scratch with whatever
findings the manifest already captured injected as a summary.
"""

from __future__ import annotations

from datetime import datetime, timedelta
from typing import Literal

from .manifest import ManifestState

# 30 minutes is roughly one-sixteenth of an 8-hour shift. A crash-and-resume
# within this window is still working the same shift's active defect set and
# the same operator context — picking back up is cheap and safe. Past this
# window, enough of the shift has moved on (new defects, a new operator, a
# stale mental model of what was being investigated) that resuming a partial
# manifest risks acting on outdated context. Past the threshold we restart
# fresh, folding whatever the manifest already found into a summary instead.
STALE_RESUME_THRESHOLD_MINUTES = 30

Decision = Literal["resume", "fresh"]


def decide(state: ManifestState, now: datetime) -> Decision:
    if not state.steps:
        return "fresh"

    if state.complete:
        return "fresh"

    last_step = state.steps[-1]
    age = now - last_step.ts
    threshold = timedelta(minutes=STALE_RESUME_THRESHOLD_MINUTES)

    if age <= threshold:
        return "resume"
    return "fresh"