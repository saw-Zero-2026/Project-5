"""Three invocation shapes.

thin     — prompt only.
rich     — hot state + new defects.
resumed  — prior partial findings + new defects since the last manifest step.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import Any, Literal

from .state import HotState

InvocationShape = Literal["thin", "rich", "resumed"]


@dataclass(frozen=True)
class Invocation:
    shape: InvocationShape
    prompt: str


def thin(prompt: str) -> Invocation:
    return Invocation(shape="thin", prompt=prompt)


def _format_defect_line(defect: Mapping[str, Any]) -> str:
    return (
        f"- {defect['id']} | {defect['ts']} | {defect.get('shift', '-')} | "
        f"{defect['component']} | {defect['severity']} | {defect['description']}"
    )


def rich(
    role: str, hot_state: HotState, new_defects: Sequence[Mapping[str, Any]]
) -> Invocation:
    lines: list[str] = [
        f"You are the on-call {role} for Northridge Plant 3.",
        "",
        "## Current hot state",
        f"- recent_defect_hashes: {', '.join(hot_state.recent_defect_hashes) or '(none)'}",
        f"- current_shift_summary: {hot_state.current_shift_summary}",
        f"- active_alerts: {', '.join(hot_state.active_alerts) or '(none)'}",
        f"- threshold_statuses: {hot_state.threshold_statuses or '(none)'}",
        "",
        "## New defects since last shift",
    ]

    if new_defects:
        for defect in new_defects:
            lines.append(_format_defect_line(defect))
    else:
        lines.append("- (none)")

    lines.extend(
        [
            "",
            "Respond with:",
            "1. Summary — a one- or two-sentence overview of this shift's findings.",
            "2. Findings — what stands out among the new defects, if anything.",
            "3. Recommended actions — concrete next steps for the incoming shift.",
            "4. Updated hot state proposal — a JSON block with the same four fields "
            "as the current hot state above, reflecting what should carry forward.",
        ]
    )

    return Invocation(shape="rich", prompt="\n".join(lines))


def _format_prior_step(step: Mapping[str, Any]) -> str:
    payload = step.get("payload", {})
    payload_str = str(payload)
    if len(payload_str) > 120:
        payload_str = payload_str[:117] + "..."
    return f"- {step.get('name', '(unnamed step)')}: {payload_str}"


def resumed(
    session_id: str,
    summary: str,
    latest_message: str,
    prior_steps: Sequence[Mapping[str, Any]],
    new_defects: Sequence[Mapping[str, Any]],
) -> Invocation:
    lines: list[str] = [
        f"Resuming session {session_id}.",
        "",
        "## Prior partial findings",
    ]

    if prior_steps:
        for step in prior_steps:
            lines.append(_format_prior_step(step))
    else:
        lines.append("- (none)")

    lines.extend(
        [
            "",
            "## Prior summary",
            summary,
            "",
            "## New defects since last partial step",
        ]
    )

    if new_defects:
        for defect in new_defects:
            lines.append(
                f"- {defect['id']} | {defect['ts']} | {defect['component']} | "
                f"{defect['severity']} | {defect['description']}"
            )
    else:
        lines.append("- (none)")

    lines.extend(
        [
            "",
            "## Latest instruction",
            latest_message,
        ]
    )

    return Invocation(shape="resumed", prompt="\n".join(lines))