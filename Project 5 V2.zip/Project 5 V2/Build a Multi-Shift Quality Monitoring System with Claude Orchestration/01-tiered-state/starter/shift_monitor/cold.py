"""Cold tier: monthly Markdown summaries derived deterministically from the warm tier."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from .warm import WarmStore


@dataclass
class ColdStore:
    store: WarmStore
    cold_dir: Path

    def write_monthly_summary(self, year: int, month: int) -> Path:
        self.cold_dir.mkdir(parents=True, exist_ok=True)

        total = self.store.count_for_month(year, month)
        top = self.store.top_components_for_month(year, month, n=3)

        lines = [
            f"# {year:04d}-{month:02d}",
            "",
            f"Total defects: {total}",
            "",
            "## Top components",
        ]

        if top:
            for component, n in top:
                unit = "defect" if n == 1 else "defects"
                lines.append(f"- {component}: {n} {unit}")
        else:
            lines.append("- (no defects recorded this month)")

        target = self.cold_dir / f"{year:04d}-{month:02d}.md"
        target.write_text("\n".join(lines) + "\n", encoding="utf-8")
        return target