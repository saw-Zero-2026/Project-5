"""Tool schemas and dispatcher.

Seven tools, registered with Anthropic tool-use shape. The dispatcher returns
serialized JSON strings to be wrapped as `tool_result` content. Errors follow
the Playbook "Graceful Tool Failure" shape:

    {"is_error": true,
     "error_category": "transient"|"permanent",
     "is_retryable": bool,
     "message": "..."}

Errors are never raised to the loop.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Callable

from claims_intake.session import ClaimSession

CLAIM_TYPES = ["property_damage", "theft", "liability", "auto"]
SEVERITIES = ["low", "medium", "high"]

# ----------------------------------------------------------------------------
# Schemas — passed verbatim to the Anthropic Messages API as the `tools` arg.
# ----------------------------------------------------------------------------

TOOL_SCHEMAS: list[dict[str, Any]] = [
    {
        "name": "lookup_policy",
        "description": (
            "Look up a policy record by its policy_id. Call this early in the "
            "conversation, as soon as you know the policy_id, to confirm the "
            "policy exists, is active, and to see its coverage and deductible. "
            "Returns the full policy record (policy_holder, coverage, "
            "deductible, status)."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "policy_id": {
                    "type": "string",
                    "description": "The policy identifier to look up, e.g. 'POL-1'.",
                },
            },
            "required": ["policy_id"],
        },
    },
    {
        "name": "record_claim_fact",
        "description": (
            "Record one normalized fact about the claim into the case file, "
            "such as incident_date, location, items_lost, or witnesses. Call "
            "this every time the claimant gives you a concrete fact worth "
            "keeping, so the case file accumulates the structured facts you "
            "will later summarize when routing or escalating the claim."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "field": {
                    "type": "string",
                    "description": "The name of the fact being recorded, e.g. 'incident_date'.",
                },
                "value": {
                    "type": "string",
                    "description": "The normalized value of the fact, e.g. '2024-03-01'.",
                },
            },
            "required": ["field", "value"],
        },
    },
    {
        "name": "classify_claim",
        "description": (
            "Commit to a classification of the claim into exactly one of the "
            "known claim types, along with your confidence in that "
            "classification and a short rationale. Call this once you have "
            "gathered enough facts to be reasonably confident about which "
            "type of claim this is — this decision determines which queue "
            "the claim is eventually routed to."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "claim_type": {
                    "type": "string",
                    "enum": CLAIM_TYPES,
                    "description": "The claim type you are committing to.",
                },
                "confidence": {
                    "type": "number",
                    "description": "Your confidence in this classification, from 0 to 1.",
                },
                "rationale": {
                    "type": "string",
                    "description": "A short explanation of why you chose this claim type.",
                },
            },
            "required": ["claim_type", "confidence", "rationale"],
        },
    },
    {
        "name": "assess_severity",
        "description": (
            "Commit to a severity bucket — low, medium, or high — for the "
            "claim, along with a short rationale. Call this once you "
            "understand the scope of the damage or loss, since severity "
            "affects how urgently the claim needs to be handled once it is "
            "routed."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "severity": {
                    "type": "string",
                    "enum": SEVERITIES,
                    "description": "The severity bucket you are committing to.",
                },
                "rationale": {
                    "type": "string",
                    "description": "A short explanation of why you chose this severity.",
                },
            },
            "required": ["severity", "rationale"],
        },
    },
    {
        "name": "request_clarification",
        "description": (
            "Ask the claimant a single targeted question when you cannot tell which "
            "of two or more claim types applies from the facts gathered so far. Use "
            "this sparingly — only when the gap genuinely blocks classification, and "
            "only once per gap. The claimant's answer may come back as the literal "
            "string NO_RESPONSE, meaning they could not answer; do not ask the same "
            "question again if that happens."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "question": {
                    "type": "string",
                    "description": "The single clarifying question to put to the claimant.",
                },
                "ambiguity_between": {
                    "type": "array",
                    "items": {"type": "string"},
                    "minItems": 2,
                    "description": (
                        "The two or more claim types this question is meant to "
                        "distinguish between."
                    ),
                },
            },
            "required": ["question", "ambiguity_between"],
        },
    },
    {
        "name": "route_to_adjuster",
        "description": (
            "Terminal tool — ends the conversation. Call this exactly once, and only "
            "after classify_claim and assess_severity have both been called, and only "
            "when your classification confidence was at least 0.6. Sends the claim to "
            "the adjuster queue matching its type. Never call this in the same "
            "conversation as escalate_to_human."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "queue": {
                    "type": "string",
                    "enum": CLAIM_TYPES,
                    "description": "Which adjuster queue to route the claim into.",
                },
                "claim_summary": {
                    "type": "string",
                    "description": "A short summary of the claim for the receiving adjuster.",
                },
            },
            "required": ["queue", "claim_summary"],
        },
    },
    {
        "name": "escalate_to_human",
        "description": (
            "Terminal tool — ends the conversation. Call this exactly once, whenever "
            "the claim cannot be routed safely: confidence is below 0.6, key facts are "
            "missing, or the claim doesn't fit cleanly into one type. Hands the claim "
            "to a human reviewer along with a structured account of the open questions. "
            "Never call this in the same conversation as route_to_adjuster."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "reason": {
                    "type": "string",
                    "description": "A short, plain-language reason this claim needs a human.",
                },
                "structured_summary": {
                    "type": "object",
                    "description": (
                        "Structured detail for the reviewer: policy_id, root_cause, "
                        "candidate_claim_types, case_facts, recommended_action, "
                        "and confidence."
                    ),
                    "properties": {
                        "policy_id": {"type": "string"},
                        "root_cause": {"type": "string"},
                        "candidate_claim_types": {
                            "type": "array",
                            "items": {"type": "string"},
                        },
                        "case_facts": {"type": "object"},
                        "recommended_action": {"type": "string"},
                        "confidence": {"type": "number"},
                    },
                    "required": [
                        "policy_id",
                        "root_cause",
                        "candidate_claim_types",
                        "case_facts",
                        "recommended_action",
                        "confidence",
                    ],
                },
            },
            "required": ["reason", "structured_summary"],
        },
    },
]

# ----------------------------------------------------------------------------
# Errors — Graceful Tool Failure shape
# ----------------------------------------------------------------------------


def _err(category: str, retryable: bool, message: str) -> str:
    return json.dumps(
        {
            "is_error": True,
            "error_category": category,
            "is_retryable": retryable,
            "message": message,
        }
    )


def _ok(payload: dict[str, Any]) -> str:
    return json.dumps(payload)


# ----------------------------------------------------------------------------
# Tool implementations
# ----------------------------------------------------------------------------


def _t_lookup_policy(session: ClaimSession, inp: dict[str, Any]) -> str:
    policy_id = inp.get("policy_id")
    if not isinstance(policy_id, str):
        return _err("permanent", False, "policy_id must be a string")

    policy = session.policies.get(policy_id)
    if policy is None:
        return _err("permanent", False, f"policy not found: {policy_id}")

    return _ok(policy)


def _t_record_claim_fact(session: ClaimSession, inp: dict[str, Any]) -> str:
    field_name = inp.get("field")
    value = inp.get("value")

    if not isinstance(field_name, str) or not isinstance(value, str):
        return _err("permanent", False, "field and value must both be strings")

    session.case_facts[field_name] = value
    return _ok(
        {
            "recorded": True,
            "field": field_name,
            "case_facts_count": len(session.case_facts),
        }
    )


def _t_classify_claim(session: ClaimSession, inp: dict[str, Any]) -> str:
    claim_type = inp.get("claim_type")
    confidence = inp.get("confidence")
    rationale = inp.get("rationale")

    if claim_type not in CLAIM_TYPES:
        return _err("permanent", False, f"claim_type must be one of {CLAIM_TYPES}")
    if isinstance(confidence, bool) or not isinstance(confidence, (int, float)):
        return _err("permanent", False, "confidence must be a number between 0 and 1")
    if not (0 <= confidence <= 1):
        return _err("permanent", False, "confidence must be between 0 and 1")
    if not isinstance(rationale, str):
        return _err("permanent", False, "rationale must be a string")

    session.classification = {
        "claim_type": claim_type,
        "confidence": confidence,
        "rationale": rationale,
    }
    return _ok({**session.classification, "recorded": True})


def _t_assess_severity(session: ClaimSession, inp: dict[str, Any]) -> str:
    severity = inp.get("severity")
    rationale = inp.get("rationale")

    if severity not in SEVERITIES:
        return _err("permanent", False, f"severity must be one of {SEVERITIES}")
    if not isinstance(rationale, str):
        return _err("permanent", False, "rationale must be a string")

    session.severity = {"severity": severity, "rationale": rationale}
    return _ok({**session.severity, "recorded": True})


def _t_request_clarification(session: ClaimSession, inp: dict[str, Any]) -> str:
    question = inp.get("question")
    ambiguity_between = inp.get("ambiguity_between")

    if not isinstance(question, str) or not question:
        return _err("permanent", False, "question must be a non-empty string")
    if not isinstance(ambiguity_between, list) or len(ambiguity_between) < 2:
        return _err(
            "permanent", False, "ambiguity_between must list at least 2 candidate types"
        )

    session.clarifications_asked.append(
        {"question": question, "ambiguity_between": ambiguity_between}
    )

    lowered = question.lower()
    for key, reply in session.clarification_responses.items():
        if key.lower() in lowered:
            return _ok({"claimant_reply": reply})

    return _ok({"claimant_reply": "NO_RESPONSE"})


def _t_route_to_adjuster(session: ClaimSession, inp: dict[str, Any]) -> str:
    if session.terminal_called:
        return _err("permanent", False, "a terminal tool was already called for this claim")

    queue = inp.get("queue")
    claim_summary = inp.get("claim_summary")

    if queue not in CLAIM_TYPES:
        return _err("permanent", False, f"queue must be one of {CLAIM_TYPES}")
    if not isinstance(claim_summary, str) or not claim_summary:
        return _err("permanent", False, "claim_summary must be a non-empty string")
    if session.classification is None:
        return _err("permanent", False, "classify_claim must be called before routing")
    if session.severity is None:
        return _err("permanent", False, "assess_severity must be called before routing")

    record = {
        "claim_id": session.claim_id,
        "policy_id": session.policy_id,
        "claim_type": session.classification["claim_type"],
        "severity": session.severity["severity"],
        "confidence": session.classification["confidence"],
        "rationale": session.classification["rationale"],
        "claim_summary": claim_summary,
        "case_facts": dict(session.case_facts),
    }
    session.routing = record
    _append_jsonl(session.run_dir / "queues" / f"{queue}.jsonl", record)
    return _ok({"routed": True, "queue": queue})


def _t_escalate_to_human(session: ClaimSession, inp: dict[str, Any]) -> str:
    if session.terminal_called:
        return _err("permanent", False, "a terminal tool was already called for this claim")

    reason = inp.get("reason")
    structured_summary = inp.get("structured_summary")

    if not isinstance(reason, str) or not reason:
        return _err("permanent", False, "reason must be a non-empty string")
    if not isinstance(structured_summary, dict):
        return _err("permanent", False, "structured_summary must be an object")

    required = [
        "policy_id",
        "root_cause",
        "candidate_claim_types",
        "case_facts",
        "recommended_action",
        "confidence",
    ]
    missing = [k for k in required if k not in structured_summary]
    if missing:
        return _err("permanent", False, f"structured_summary is missing fields: {missing}")

    record = {
        "claim_id": session.claim_id,
        "policy_id": session.policy_id,
        "reason": reason,
        **structured_summary,
        "case_facts_at_escalation": dict(session.case_facts),
    }
    session.escalation = record
    _append_jsonl(session.run_dir / "escalations.jsonl", record)
    return _ok({"escalated": True})


# ----------------------------------------------------------------------------
# Dispatcher
# ----------------------------------------------------------------------------

Executor = Callable[[str, dict[str, Any]], str]
"""Type alias for clarity; the loop only sees a Callable."""

_DISPATCH = {
    "lookup_policy": _t_lookup_policy,
    "record_claim_fact": _t_record_claim_fact,
    "classify_claim": _t_classify_claim,
    "assess_severity": _t_assess_severity,
    "request_clarification": _t_request_clarification,
    "route_to_adjuster": _t_route_to_adjuster,
    "escalate_to_human": _t_escalate_to_human,
}


def make_executor(session: ClaimSession) -> Executor:
    """Return a ToolExecutor callable bound to this session."""

    def execute(name: str, tool_input: dict[str, Any]) -> str:
        handler = _DISPATCH.get(name)
        if handler is None:
            return _err("permanent", False, f"unknown tool: {name}")
        try:
            return handler(session, tool_input)
        except Exception as exc:
            # Defensive: anything raised inside a handler becomes a graceful error,
            # never crashes the loop.
            return _err("transient", True, f"{type(exc).__name__}: {exc}")

    return execute


def _append_jsonl(path: Path, record: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(record, ensure_ascii=False) + "\n")