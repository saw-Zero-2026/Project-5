"""Anti-pattern audit.

Verifies, by static AST analysis, that the agentic loop does NOT:
- use string-membership tests against text content to drive control flow
- use an integer-literal iteration cap as its primary stopping mechanism
- omit reference to `stop_reason` as the loop-breaking signal

And that the package broadly does not branch on `claim_type` equality
outside of the tool-schema definitions and the cost-estimate module.

Each test parses the relevant file with `ast` and walks the tree. There are
no runtime imports of claims_intake here — the audit is static, so it works
even if loop.py / tools.py do not run end-to-end.
"""

from __future__ import annotations

import ast
from pathlib import Path

PKG = Path(__file__).resolve().parents[1] / "claims_intake"
LOOP_PY = PKG / "loop.py"


def _parse(path: Path) -> ast.Module:
    return ast.parse(path.read_text(encoding="utf-8"), filename=str(path))


# ---------------------------------------------------------------------------
# Anti-pattern 1 — no string-membership tests against assistant text in the loop
# ---------------------------------------------------------------------------
def test_no_string_membership_against_text_in_loop() -> None:
    """No `"some_token" in <something>` expressions in loop.py.

    Heuristic: any `ast.Compare` node using `ast.In` whose `left` operand is a
    string `ast.Constant` is flagged. The loop has no legitimate reason to test
    for the presence of a magic string inside the model's output — that would be
    natural-language-driven control flow.
    """
    tree = _parse(LOOP_PY)
    offenders: list[str] = []

    for node in ast.walk(tree):
        if not isinstance(node, ast.Compare):
            continue
        if not any(isinstance(op, ast.In) for op in node.ops):
            continue
        left = node.left
        if isinstance(left, ast.Constant) and isinstance(left.value, str):
            offenders.append(ast.unparse(node))

    assert not offenders, (
        "Found string-membership test(s) against text driving control flow "
        f"in loop.py: {offenders}"
    )


# ---------------------------------------------------------------------------
# Anti-pattern 2 — no integer-literal iteration cap as the primary stop mechanism
# ---------------------------------------------------------------------------
def test_no_integer_literal_iteration_cap_in_loop() -> None:
    """No `for _ in range(<int literal>)` and no `while <var> < <int literal>` in loop.py.

    Token/wall-clock/config-sourced budgets are explicitly allowed because they
    read their cap from a `Budget` instance (an attribute access or a function
    arg), not from a literal. If you need a cap, pass it in.
    """
    tree = _parse(LOOP_PY)
    offenders: list[str] = []

    for node in ast.walk(tree):
        if isinstance(node, ast.For):
            it = node.iter
            if (
                isinstance(it, ast.Call)
                and isinstance(it.func, ast.Name)
                and it.func.id == "range"
                and any(
                    isinstance(arg, ast.Constant) and isinstance(arg.value, int)
                    for arg in it.args
                )
            ):
                offenders.append(ast.unparse(node).splitlines()[0])

        if isinstance(node, ast.While):
            test = node.test
            if isinstance(test, ast.Compare):
                for comparator in test.comparators:
                    if isinstance(comparator, ast.Constant) and isinstance(
                        comparator.value, int
                    ):
                        offenders.append(ast.unparse(test))

    assert not offenders, (
        "Found an integer-literal iteration cap in loop.py; use a Budget "
        f"instead: {offenders}"
    )


# ---------------------------------------------------------------------------
# Positive evidence — stop_reason is the value that breaks the while loop
# ---------------------------------------------------------------------------
def test_stop_reason_is_loop_control() -> None:
    """loop.py references `stop_reason` AND a `while` loop exits via return/raise on it."""
    tree = _parse(LOOP_PY)

    has_stop_reason_reference = any(
        (isinstance(node, ast.Attribute) and node.attr == "stop_reason")
        or (isinstance(node, ast.Name) and node.id == "stop_reason")
        for node in ast.walk(tree)
    )
    assert has_stop_reason_reference, "loop.py never references stop_reason"

    while_nodes = [node for node in ast.walk(tree) if isinstance(node, ast.While)]
    assert while_nodes, "loop.py has no while loop"

    exits_on_stop_reason = False
    for while_node in while_nodes:
        body_src = "\n".join(ast.unparse(stmt) for stmt in while_node.body)
        if "stop_reason" in body_src and ("return" in body_src or "raise" in body_src):
            exits_on_stop_reason = True
            break

    assert exits_on_stop_reason, (
        "No while loop in loop.py exits (via return/raise) based on stop_reason"
    )


# ---------------------------------------------------------------------------
# Decision-tree-in-Python — no `if claim_type == "..."` branches in the package
# ---------------------------------------------------------------------------
def test_no_claim_type_equality_branching_in_package() -> None:
    """Decision logic about claim type lives in the model, not in Python.

    tools.py is exempt (it defines the enum in input_schema).
    pricing.py is exempt (it may map claim_type to per-queue cost weights).
    """
    skip_files = {"tools.py", "pricing.py", "__init__.py"}
    offenders: list[str] = []

    for py_file in sorted(PKG.rglob("*.py")):
        if py_file.name in skip_files:
            continue

        tree = ast.parse(py_file.read_text(encoding="utf-8"), filename=str(py_file))

        for node in ast.walk(tree):
            if not isinstance(node, ast.Compare):
                continue
            if not any(isinstance(op, ast.Eq) for op in node.ops):
                continue

            left = node.left
            is_claim_type = (
                (isinstance(left, ast.Name) and left.id == "claim_type")
                or (isinstance(left, ast.Attribute) and left.attr == "claim_type")
            )
            if not is_claim_type:
                continue

            if any(
                isinstance(c, ast.Constant) and isinstance(c.value, str)
                for c in node.comparators
            ):
                offenders.append(f"{py_file.name}:{node.lineno}: {ast.unparse(node)}")

    assert not offenders, (
        "Found if claim_type == '...' branching outside tools.py/pricing.py; "
        f"move this decision into the model via tool calls: {offenders}"
    )