"""Anti-pattern audit.

Verifies, by static AST analysis, that the agentic loop does NOT:
- use string-membership tests against text content to drive control flow
- use an integer-literal iteration cap as its primary stopping mechanism
- omit reference to `stop_reason` as the loop-breaking signal

And that the package broadly does not branch on `claim_type` equality
outside of the tool-schema definitions and the cost-estimate module.

Each test parses the relevant file with `ast` and walks the tree. There are
no runtime imports of claims_intake here — the audit is static, so it works
even if loop.py / tools.py do not run end-to-end.
"""

from __future__ import annotations

import ast
from pathlib import Path

PKG = Path(__file__).resolve().parents[1] / "claims_intake"
LOOP_PY = PKG / "loop.py"


def _parse(path: Path) -> ast.Module:
    return ast.parse(path.read_text(encoding="utf-8"), filename=str(path))


# ---------------------------------------------------------------------------
# Anti-pattern 1 — no string-membership tests against assistant text in the loop
# ---------------------------------------------------------------------------
def test_no_string_membership_against_text_in_loop() -> None:
    """No `"some_token" in <something>` expressions in loop.py.

    Heuristic: any `ast.Compare` node using `ast.In` whose `left` operand is a
    string `ast.Constant` is flagged. The loop has no legitimate reason to test
    for the presence of a magic string inside the model's output — that would be
    natural-language-driven control flow.
    """
    tree = _parse(LOOP_PY)
    offenders: list[str] = []

    for node in ast.walk(tree):
        if not isinstance(node, ast.Compare):
            continue
        if not any(isinstance(op, ast.In) for op in node.ops):
            continue
        left = node.left
        if isinstance(left, ast.Constant) and isinstance(left.value, str):
            offenders.append(ast.unparse(node))

    assert not offenders, (
        "loop.py must not branch on string membership against model text — found:\n"
        + "\n".join(offenders)
    )


# ---------------------------------------------------------------------------
# Anti-pattern 2 — no integer-literal iteration cap as the primary stop mechanism
# ---------------------------------------------------------------------------
def test_no_integer_literal_iteration_cap_in_loop() -> None:
    """No `for _ in range(<int literal>)` and no `while <var> < <int literal>` in loop.py.

    Token/wall-clock/config-sourced budgets are explicitly allowed because they
    read their cap from a `Budget` instance (an attribute access or a function
    arg), not from a literal. If you need a cap, pass it in.
    """
    tree = _parse(LOOP_PY)
    offenders: list[str] = []

    for node in ast.walk(tree):
        if isinstance(node, ast.For):
            call = node.iter
            if (
                isinstance(call, ast.Call)
                and isinstance(call.func, ast.Name)
                and call.func.id == "range"
                and any(
                    isinstance(arg, ast.Constant) and isinstance(arg.value, int)
                    for arg in call.args
                )
            ):
                offenders.append(f"line {node.lineno}: {ast.unparse(node.iter)}")

        elif isinstance(node, ast.While):
            test = node.test
            if isinstance(test, ast.Compare):
                literal_operands = [
                    n
                    for n in (test.left, *test.comparators)
                    if isinstance(n, ast.Constant) and isinstance(n.value, int)
                ]
                if literal_operands:
                    offenders.append(f"line {node.lineno}: {ast.unparse(test)}")

    assert not offenders, (
        "loop.py must not use an integer-literal iteration cap as its stop "
        "mechanism — use a Budget instead. Offending lines:\n"
        + "\n".join(offenders)
    )


# ---------------------------------------------------------------------------
# Positive evidence — stop_reason is the value that breaks the while loop
# ---------------------------------------------------------------------------
def test_stop_reason_is_loop_control() -> None:
    """loop.py references `stop_reason` AND a `while` loop exits via return/raise on it."""
    tree = _parse(LOOP_PY)

    references_stop_reason = any(
        (isinstance(node, ast.Attribute) and node.attr == "stop_reason")
        or (isinstance(node, ast.Name) and node.id == "stop_reason")
        for node in ast.walk(tree)
    )
    assert references_stop_reason, (
        "loop.py never references stop_reason — the loop must inspect the "
        "API response's stop_reason to decide whether to continue."
    )

    while_nodes = [n for n in ast.walk(tree) if isinstance(n, ast.While)]
    assert while_nodes, "loop.py has no while loop to drive turn-by-turn iteration."

    exits_on_stop_reason = False
    for node in while_nodes:
        body_src = "\n".join(ast.unparse(stmt) for stmt in node.body)
        mentions_stop_reason = "stop_reason" in body_src
        mentions_exit = "return" in body_src or "raise" in body_src
        if mentions_stop_reason and mentions_exit:
            exits_on_stop_reason = True
            break

    assert exits_on_stop_reason, (
        "no while loop in loop.py both references stop_reason and exits via "
        "return/raise inside its body — the loop must terminate based on "
        "stop_reason, not on some other condition."
    )


# ---------------------------------------------------------------------------
# Decision-tree-in-Python — no `if claim_type == "..."` branches in the package
# ---------------------------------------------------------------------------
def test_no_claim_type_equality_branching_in_package() -> None:
    """Decision logic about claim type lives in the model, not in Python.

    tools.py is exempt (it defines the enum in input_schema).
    pricing.py is exempt (it may map claim_type to per-queue cost weights).
    """
    exempt = {"tools.py", "pricing.py", "__init__.py"}
    offenders: list[str] = []

    def _is_claim_type_name(node: ast.expr) -> bool:
        if isinstance(node, ast.Name):
            return node.id == "claim_type"
        if isinstance(node, ast.Attribute):
            return node.attr == "claim_type"
        return False

    for path in PKG.rglob("*.py"):
        if path.name in exempt:
            continue

        tree = _parse(path)
        for node in ast.walk(tree):
            if not isinstance(node, ast.Compare):
                continue
            if not any(isinstance(op, ast.Eq) for op in node.ops):
                continue
            if not _is_claim_type_name(node.left):
                continue
            if any(
                isinstance(comp, ast.Constant) and isinstance(comp.value, str)
                for comp in node.comparators
            ):
                offenders.append(f"{path.name}:{node.lineno}: {ast.unparse(node)}")

    assert not offenders, (
        "found claim_type equality branching outside tools.py/pricing.py — "
        "move this decision into the model via tool calls instead:\n"
        + "\n".join(offenders)
    )