"""Tool schemas and dispatcher.

Seven tools, registered with Anthropic tool-use shape. The dispatcher returns
serialized JSON strings to be wrapped as `tool_result` content. Errors follow
the Playbook "Graceful Tool Failure" shape:

    {"is_error": true,
     "error_category": "transient"|"permanent",
     "is_retryable": bool,
     "message": "..."}

Errors are never raised to the loop.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Callable

from claims_intake.session import ClaimSession

CLAIM_TYPES = ["property_damage", "theft", "liability", "auto"]
SEVERITIES = ["low", "medium", "high"]

# ----------------------------------------------------------------------------
# Schemas — passed verbatim to the Anthropic Messages API as the `tools` arg.
# ----------------------------------------------------------------------------

TOOL_SCHEMAS: list[dict[str, Any]] = [
    {
        "name": "lookup_policy",
        "description": (
            "Fetch the policy record for this claim so you know what's covered before "
            "asking the claimant anything further. Call this once, early — ideally as your "
            "first tool call — using the policy_id already provided at the start of the "
            "conversation."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "policy_id": {
                    "type": "string",
                    "description": "The policy identifier for this claim.",
                }
            },
            "required": ["policy_id"],
        },
    },
    {
        "name": "record_claim_fact",
        "description": (
            "Save one discrete fact about the claim as it's told to you — for example an "
            "incident_date, location, description, items_lost, injury_party, or "
            "estimated_damage. Call this once per new fact, right after the claimant states "
            "it. Do not call it again for a fact you've already recorded unless the "
            "claimant corrects it."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "field": {
                    "type": "string",
                    "description": (
                        "Short snake_case name for this fact, e.g. incident_date, "
                        "location, estimated_damage."
                    ),
                },
                "value": {
                    "type": "string",
                    "description": "The fact itself, as stated by the claimant.",
                },
            },
            "required": ["field", "value"],
        },
    },
    {
        "name": "classify_claim",
        "description": (
            "Commit to a claim type once you have enough facts to decide. Call this "
            "exactly once per claim, after you've gathered facts and resolved any real "
            "ambiguity — not before. Your confidence score here drives whether the claim "
            "can later be routed automatically or must be escalated."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "claim_type": {
                    "type": "string",
                    "enum": CLAIM_TYPES,
                    "description": "Your best determination of the claim type.",
                },
                "confidence": {
                    "type": "number",
                    "description": "How confident you are in claim_type, from 0 to 1.",
                },
                "rationale": {
                    "type": "string",
                    "description": "One sentence tying this classification to specific facts.",
                },
            },
            "required": ["claim_type", "confidence", "rationale"],
        },
    },
    {
        "name": "assess_severity",
        "description": (
            "Commit to a severity bucket once claim_type is set. Call this exactly once "
            "per claim, after classify_claim. This determines urgency and, alongside your "
            "confidence, whether the claim routes automatically."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "severity": {
                    "type": "string",
                    "enum": SEVERITIES,
                    "description": "The severity bucket for this claim.",
                },
                "rationale": {
                    "type": "string",
                    "description": "One sentence tying this severity to specific facts.",
                },
            },
            "required": ["severity", "rationale"],
        },
    },
    {
        "name": "request_clarification",
        "description": (
            "Ask the claimant a single focused question when the claim type is genuinely "
            "ambiguous between two or more candidates and you cannot proceed without an "
            "answer. Call this at most once per distinct missing piece of information — "
            "never repeat the same question. The claimant may be unable to respond, in "
            "which case you'll get back NO_RESPONSE and should not ask again."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "question": {
                    "type": "string",
                    "description": "The single question to ask the claimant.",
                },
                "ambiguity_between": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": (
                        "The two or more candidate claim types this question is meant "
                        "to distinguish between."
                    ),
                },
            },
            "required": ["question", "ambiguity_between"],
        },
    },
    {
        "name": "route_to_adjuster",
        "description": (
            "Terminal tool. Call this exactly once, only after classify_claim and "
            "assess_severity are both set and your classification confidence is at least "
            "0.6. This sends the claim to the matching adjuster queue and ends the "
            "conversation. Never call this and escalate_to_human in the same claim."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "queue": {
                    "type": "string",
                    "enum": CLAIM_TYPES,
                    "description": "The adjuster queue to route this claim to.",
                },
                "claim_summary": {
                    "type": "string",
                    "description": "A short summary of the claim for the adjuster.",
                },
            },
            "required": ["queue", "claim_summary"],
        },
    },
    {
        "name": "escalate_to_human",
        "description": (
            "Terminal tool. Call this exactly once when you cannot route the claim safely "
            "— low confidence, missing critical facts, or anything that doesn't fit "
            "cleanly. This hands the claim to a human reviewer and ends the conversation. "
            "Never call this and route_to_adjuster in the same claim."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "reason": {
                    "type": "string",
                    "description": "Short explanation of why this claim needs a human.",
                },
                "structured_summary": {
                    "type": "object",
                    "description": (
                        "A structured summary for the reviewer, containing policy_id, "
                        "root_cause, candidate_claim_types, case_facts, "
                        "recommended_action, and confidence."
                    ),
                    "properties": {
                        "policy_id": {"type": "string"},
                        "root_cause": {"type": "string"},
                        "candidate_claim_types": {
                            "type": "array",
                            "items": {"type": "string"},
                        },
                        "case_facts": {"type": "object"},
                        "recommended_action": {"type": "string"},
                        "confidence": {"type": "number"},
                    },
                    "required": [
                        "policy_id",
                        "root_cause",
                        "candidate_claim_types",
                        "case_facts",
                        "recommended_action",
                        "confidence",
                    ],
                },
            },
            "required": ["reason", "structured_summary"],
        },
    },
]

# ----------------------------------------------------------------------------
# Errors — Graceful Tool Failure shape
# ----------------------------------------------------------------------------


def _err(category: str, retryable: bool, message: str) -> str:
    return json.dumps(
        {
            "is_error": True,
            "error_category": category,
            "is_retryable": retryable,
            "message": message,
        },
        ensure_ascii=False,
    )


def _ok(payload: dict[str, Any]) -> str:
    return json.dumps(payload, ensure_ascii=False)


# ----------------------------------------------------------------------------
# Tool implementations
# ----------------------------------------------------------------------------


def _t_lookup_policy(session: ClaimSession, inp: dict[str, Any]) -> str:
    policy_id = inp.get("policy_id")
    if not isinstance(policy_id, str):
        return _err("permanent", False, "policy_id must be a string")
    policy = session.policies.get(policy_id)
    if policy is None:
        return _err("permanent", False, f"no policy found for policy_id={policy_id!r}")
    return _ok(policy)


def _t_record_claim_fact(session: ClaimSession, inp: dict[str, Any]) -> str:
    field_name = inp.get("field")
    value = inp.get("value")
    if not isinstance(field_name, str) or not field_name:
        return _err("permanent", False, "field must be a non-empty string")
    if not isinstance(value, str):
        return _err("permanent", False, "value must be a string")
    session.case_facts[field_name] = value
    return _ok(
        {
            "recorded": True,
            "field": field_name,
            "case_facts_count": len(session.case_facts),
        }
    )


def _t_classify_claim(session: ClaimSession, inp: dict[str, Any]) -> str:
    claim_type = inp.get("claim_type")
    confidence = inp.get("confidence")
    rationale = inp.get("rationale")

    if claim_type not in CLAIM_TYPES:
        return _err(
            "permanent", False, f"claim_type must be one of {CLAIM_TYPES}, got {claim_type!r}"
        )
    if not isinstance(confidence, (int, float)) or isinstance(confidence, bool):
        return _err("permanent", False, "confidence must be a number")
    if not (0 <= confidence <= 1):
        return _err("permanent", False, "confidence must be between 0 and 1")
    if not isinstance(rationale, str) or not rationale:
        return _err("permanent", False, "rationale must be a non-empty string")

    session.classification = {
        "claim_type": claim_type,
        "confidence": confidence,
        "rationale": rationale,
    }
    return _ok({**session.classification, "recorded": True})


def _t_assess_severity(session: ClaimSession, inp: dict[str, Any]) -> str:
    severity = inp.get("severity")
    rationale = inp.get("rationale")

    if severity not in SEVERITIES:
        return _err(
            "permanent", False, f"severity must be one of {SEVERITIES}, got {severity!r}"
        )
    if not isinstance(rationale, str) or not rationale:
        return _err("permanent", False, "rationale must be a non-empty string")

    session.severity = {"severity": severity, "rationale": rationale}
    return _ok({**session.severity, "recorded": True})


def _t_request_clarification(session: ClaimSession, inp: dict[str, Any]) -> str:
    question = inp.get("question")
    ambiguity_between = inp.get("ambiguity_between")

    if not isinstance(question, str) or not question:
        return _err("permanent", False, "question must be a non-empty string")
    if not isinstance(ambiguity_between, list) or len(ambiguity_between) < 2:
        return _err(
            "permanent", False, "ambiguity_between must be a list of at least 2 candidates"
        )

    session.clarifications_asked.append(
        {"question": question, "ambiguity_between": ambiguity_between}
    )

    question_lower = question.lower()
    for key, reply in session.clarification_responses.items():
        if key.lower() in question_lower:
            return _ok({"claimant_reply": reply})

    return _ok({"claimant_reply": "NO_RESPONSE"})


def _t_route_to_adjuster(session: ClaimSession, inp: dict[str, Any]) -> str:
    if session.terminal_called:
        return _err("permanent", False, "a terminal tool has already been called for this claim")

    queue = inp.get("queue")
    claim_summary = inp.get("claim_summary")

    if queue not in CLAIM_TYPES:
        return _err("permanent", False, f"queue must be one of {CLAIM_TYPES}, got {queue!r}")
    if not isinstance(claim_summary, str) or not claim_summary:
        return _err("permanent", False, "claim_summary must be a non-empty string")
    if session.classification is None:
        return _err("permanent", False, "cannot route before classify_claim has been called")
    if session.severity is None:
        return _err("permanent", False, "cannot route before assess_severity has been called")

    record = {
        "claim_id": session.claim_id,
        "policy_id": session.policy_id,
        "claim_type": session.classification["claim_type"],
        "severity": session.severity["severity"],
        "confidence": session.classification["confidence"],
        "rationale": session.classification["rationale"],
        "claim_summary": claim_summary,
        "case_facts": dict(session.case_facts),
    }
    session.routing = record
    _append_jsonl(session.run_dir / "queues" / f"{queue}.jsonl", record)
    return _ok({"routed": True, "queue": queue})


def _t_escalate_to_human(session: ClaimSession, inp: dict[str, Any]) -> str:
    if session.terminal_called:
        return _err("permanent", False, "a terminal tool has already been called for this claim")

    reason = inp.get("reason")
    structured_summary = inp.get("structured_summary")

    if not isinstance(reason, str) or not reason:
        return _err("permanent", False, "reason must be a non-empty string")
    if not isinstance(structured_summary, dict):
        return _err("permanent", False, "structured_summary must be an object")

    required_keys = [
        "policy_id",
        "root_cause",
        "candidate_claim_types",
        "case_facts",
        "recommended_action",
        "confidence",
    ]
    missing = [k for k in required_keys if k not in structured_summary]
    if missing:
        return _err(
            "permanent", False, f"structured_summary missing required fields: {missing}"
        )

    record = {
        "claim_id": session.claim_id,
        "policy_id": session.policy_id,
        "reason": reason,
        **structured_summary,
        "case_facts_at_escalation": dict(session.case_facts),
    }
    session.escalation = record
    _append_jsonl(session.run_dir / "escalations.jsonl", record)
    return _ok({"escalated": True})


# ----------------------------------------------------------------------------
# Dispatcher
# ----------------------------------------------------------------------------

# Type alias for clarity; the loop only sees a Callable.
Executor = Callable[[str, dict[str, Any]], str]

_DISPATCH = {
    "lookup_policy": _t_lookup_policy,
    "record_claim_fact": _t_record_claim_fact,
    "classify_claim": _t_classify_claim,
    "assess_severity": _t_assess_severity,
    "request_clarification": _t_request_clarification,
    "route_to_adjuster": _t_route_to_adjuster,
    "escalate_to_human": _t_escalate_to_human,
}


def make_executor(session: ClaimSession) -> Executor:
    """Return a ToolExecutor callable bound to this session."""

    def execute(name: str, tool_input: dict[str, Any]) -> str:
        handler = _DISPATCH.get(name)
        if handler is None:
            return _err("permanent", False, f"unknown tool: {name}")
        try:
            return handler(session, tool_input)
        except Exception as exc:
            # Defensive: anything raised inside a handler becomes a graceful error,
            # never crashes the loop.
            return _err("transient", True, f"{type(exc).__name__}: {exc}")

    return execute


def _append_jsonl(path: Path, record: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(record, ensure_ascii=False) + "\n")