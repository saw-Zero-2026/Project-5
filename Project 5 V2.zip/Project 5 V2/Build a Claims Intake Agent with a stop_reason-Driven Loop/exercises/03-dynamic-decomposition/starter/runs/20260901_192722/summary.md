# Run summary — 20260901_192722

- Model: `claude-haiku-4-5-20251001`
- Fixtures processed: 8
- Estimated total cost: **$0.1792** USD

| claim_id | outcome | claim_type | severity | turns | clarifications_asked | input_tokens | output_tokens | est_cost_usd | elapsed_s |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| claim_01_kitchen_fire | routed | property_damage | medium | 4 | 0 | 16170 | 852 | 0.0204 | 10.5 |
| claim_02_stolen_bike | routed | theft | low | 4 | 0 | 15491 | 727 | 0.0191 | 8.8 |
| claim_03_water_damage | routed | property_damage | high | 4 | 1 | 15848 | 1037 | 0.021 | 13.2 |
| claim_04_neighbor_injury | routed | liability | high | 4 | 0 | 16424 | 953 | 0.0212 | 11.4 |
| claim_05_auto_collision | routed | auto | high | 4 | 0 | 16431 | 935 | 0.0211 | 12.0 |
| claim_06_low_confidence_escalation | escalated | property_damage,liability | - | 5 | 1 | 22126 | 1531 | 0.0298 | 17.0 |
| claim_07_tree_falls_on_car | routed | auto | medium | 5 | 1 | 20709 | 1130 | 0.0264 | 14.3 |
| claim_08_minor_porch_damage | routed | property_damage | low | 4 | 0 | 15986 | 846 | 0.0202 | 12.1 |
