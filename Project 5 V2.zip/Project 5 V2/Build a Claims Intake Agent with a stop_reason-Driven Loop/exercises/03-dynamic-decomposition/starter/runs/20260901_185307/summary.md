# Run summary — 20260901_185307

- Model: `claude-haiku-4-5-20251001`
- Fixtures processed: 8
- Estimated total cost: **$0.1714** USD

| claim_id | outcome | claim_type | severity | turns | clarifications_asked | input_tokens | output_tokens | est_cost_usd | elapsed_s |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| claim_01_kitchen_fire | routed | property_damage | medium | 4 | 0 | 15415 | 871 | 0.0198 | 12.1 |
| claim_02_stolen_bike | routed | theft | low | 4 | 0 | 14725 | 742 | 0.0184 | 8.5 |
| claim_03_water_damage | incomplete | - | - | 2 | 0 | 6503 | 373 | 0.0084 | 4.3 |
| claim_04_neighbor_injury | routed | liability | high | 6 | 2 | 24000 | 1171 | 0.0299 | 16.8 |
| claim_05_auto_collision | routed | auto | high | 4 | 0 | 16092 | 1020 | 0.0212 | 10.2 |
| claim_06_low_confidence_escalation | routed | property_damage | high | 7 | 2 | 28332 | 1384 | 0.0353 | 20.5 |
| claim_07_tree_falls_on_car | routed | auto | medium | 4 | 0 | 15238 | 857 | 0.0195 | 9.3 |
| claim_08_minor_porch_damage | routed | property_damage | low | 4 | 0 | 15133 | 779 | 0.019 | 8.4 |
